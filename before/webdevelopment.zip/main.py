from https import Http

HOST, PORT = "0.0.0.0", 8001

# 创建服务器实例
http = Http(HOST, PORT)

# 使用装饰器注册路由
@http.route("/")
def get_root():
    return "<h1>Hello</h1>"

@http.route("/hello")
def get_hello():
    return "<h1>Hello World</h1>"

@http.route("/cv")
def get_cv():
    with open("cv.html", "r", encoding="utf-8") as f:
        return f.read()

# 启动服务器
http.run()
